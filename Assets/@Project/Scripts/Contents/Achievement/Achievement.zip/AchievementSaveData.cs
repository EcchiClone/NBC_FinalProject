public struct AchievementSaveData
{
    public string codeName;
    public AchievementState state;
    public int taskGroupIndex;
    public int[] taskSuccessCounts;
}